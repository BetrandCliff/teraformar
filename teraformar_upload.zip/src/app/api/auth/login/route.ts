import { NextResponse } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { createAdminSession } from "@/lib/typeorm";

export async function POST(request: Request) {
  const adminPassword = process.env.ADMIN_PASSWORD;
  if (!adminPassword || !process.env.SESSION_SECRET) return NextResponse.json({ error: "Admin login is not configured" }, { status: 503 });
  let body: { email?: string; password?: string };
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Email and password are required" }, { status: 400 }); }
  if (typeof body.email !== "string" || typeof body.password !== "string" || !body.email.trim() || !body.password) return NextResponse.json({ error: "Email and password are required" }, { status: 400 });
  const allowed = process.env.ADMIN_EMAILS?.split(",").map((email) => email.trim().toLowerCase()).filter(Boolean) ?? [];
  const email = body.email.trim().toLowerCase();
  const supplied = Buffer.from(body.password);
  const expected = Buffer.from(adminPassword);
  if (!allowed.includes(email) || supplied.length !== expected.length || !timingSafeEqual(supplied, expected))
    return NextResponse.json({ error: "Invalid email or password" }, { status: 401 });
  const session = createAdminSession(email);
  const out = NextResponse.json({ ok: true });
  out.cookies.set("buildvision_session", session.token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: session.maxAge });
  return out;
}
